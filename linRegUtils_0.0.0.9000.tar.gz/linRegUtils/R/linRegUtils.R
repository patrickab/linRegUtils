devtools::build("linRegUtils")
